from setuptools import setup, Extension

solver_module = Extension('solver',
                          sources=['solver.cpp'])

setup(name='Solver',
      version='1',
      description='Lib',
      ext_modules=[solver_module])
