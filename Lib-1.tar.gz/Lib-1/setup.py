from setuptools import setup, find_packages

setup(
    name="Lib",
    version="1",
    author="Bartosz Polański",
    author_email="226581@student.pwr.edu.pl",
    description="DPP",
    license='MIT',
    url='https://github.com/MrBarozoIT/DPP.git',
    packages=find_packages(exclude=['tests']),
    python_requires='>=3.6',
    long_description=open('README.md').read(),
    zip_safe=False
)
